import sys

import os

from JackTokenizer import JackTokenizer


opSet = {"+", "-", "*", "/", "&amp;", "|", "&lt;", "&gt;", "="}
unaryOpSet = {"-", "~"}
keyWordConstantSet = {"true", "false", "null", "this"}
statementSet = {"let", "if", "while", "do", "return"}


class CompilationEngine:

    def __init__(self, input_file, output_file):
        self.j = JackTokenizer(input_file)
        self.output = output_file
        self.current_token = None
        self.scope_counter = 0

    def get_next_token(self):
        token = None
        if (self.j.has_more_tokens()):
            self.j.advance()
            cur_type = self.j.token_type()
            if (cur_type is "keyword"):
                token = self.j.keyword()
            if (cur_type is "symbol"):
                token = self.j.symbol()
            if (cur_type is "identifier"):
                token = self.j.identifier()
            if (cur_type is "integerConstant"):
                token = self.j.int_val()
            if (cur_type is "stringConstant"):
                token = self.j.string_val()
        self.current_token = token
        return token

    def write_to_file(self):
        for i in range(self.scope_counter):
            self.output.write("\t")
        self.output.write("<" + self.j.token_type() + "> " + str(self.current_token) + " </" + self.j.token_type() + ">\n")

    def write_title_to_file(self, title):
        for i in range(self.scope_counter):
            self.output.write("\t")
        self.output.write("<" + title + ">\n")

    def checkSpecificToken(self, expectedTokenType, excpectedToken):

        if (self.j.token_type() == expectedTokenType and self.current_token == excpectedToken):
            self.write_to_file()


    def CompileClass(self):
        self.write_title_to_file("class")
        self.scope_counter += 1
        self.get_next_token()
        self.checkSpecificToken("keyword", "class")
        self.get_next_token()
        if (self.j.token_type() == "identifier"):
            self.write_to_file()

        self.get_next_token()
        if (self.j.token_type() == "symbol" and self.current_token == "{"):
            self.write_to_file()

        self.get_next_token()
        while (self.j.token_type() == "keyword" and (self.current_token == "static" or
                                                     self.current_token == "field")):
            self.CompileClassVarDec()

        while (self.j.token_type() == "keyword" and (self.current_token == "constructor" or
                 self.current_token == "function" or self.current_token == "method")):
            self.CompileSubroutine()

        self.checkSpecificToken("symbol", "}")

        self.scope_counter -= 1
        self.write_title_to_file("/class")


    def CompileClassVarDec(self):
        self.write_title_to_file("classVarDec")
        self.scope_counter += 1
        self.write_to_file()
        self.get_next_token()
        self.handleType()

        self.get_next_token()
        if (self.j.token_type() == "identifier"):
            self.write_to_file()

        self.get_next_token()
        while (self.j.token_type() == "symbol" and self.current_token == ","):
            self.write_to_file()
            self.get_next_token()
            if (self.j.token_type() == "identifier"):
                self.write_to_file()
            self.get_next_token()

        self.checkSpecificToken("symbol", ";")

        self.get_next_token()
        self.scope_counter -= 1
        self.write_title_to_file("/classVarDec")



    def CompileSubroutine(self):
        self.write_title_to_file("subroutineDec")
        self.scope_counter += 1
        self.write_to_file()

        self.get_next_token()
        if ((self.j.token_type() == "keyword" and (self.current_token == "int"
                   or self.current_token == "char" or self.current_token == "boolean"
                   or self.current_token == "void")) or self.j.token_type() == "identifier"):
            self.write_to_file()

        self.get_next_token()
        if (self.j.token_type() == "identifier"):
            self.write_to_file()

        self.get_next_token()
        self.checkSpecificToken("symbol", "(")

        self.get_next_token()
        ## if the constructor/ function/ method has any parameters:
        if (self.j.token_type() == "symbol" and self.current_token == ")"):
            self.CompileParameterList(False)
        else:
            self.CompileParameterList(True)
        self.checkSpecificToken("symbol", ")")

        self.get_next_token()
        self.CompileSubroutineBody()

        self.scope_counter -= 1
        self.write_title_to_file("/subroutineDec")



    def handleType(self):
        if ((self.j.token_type() == "keyword" and (self.current_token == "int" or
               self.current_token == "char" or self.current_token == "boolean"))
                or self.j.token_type() == "identifier"):
            self.write_to_file()


    def CompileParameterList(self, hasArguments):
        self.write_title_to_file("parameterList")
        self.scope_counter += 1
        if (hasArguments):
            if ((self.j.token_type() == "keyword" and (self.current_token == "int" or self.current_token == "char" or
                self.current_token == "boolean")) or self.j.token_type() == "identifier"):
                self.write_to_file()

                self.get_next_token()
                if (self.j.token_type() == "identifier"):
                    self.write_to_file()

                self.get_next_token()
                while (self.j.token_type() == "symbol" and self.current_token == ","):
                    self.write_to_file()
                    self.get_next_token()
                    if ((self.j.token_type() == "keyword" and (
                            self.current_token == "int" or self.current_token == "char" or
                            self.current_token == "boolean")) or self.j.token_type() == "identifier"):
                        self.write_to_file()

                    self.get_next_token()
                    if (self.j.token_type() == "identifier"):
                        self.write_to_file()
                    self.get_next_token()

        self.scope_counter -= 1
        self.write_title_to_file("/parameterList")


    def CompileSubroutineBody(self):
        self.write_title_to_file("subroutineBody")
        self.scope_counter += 1

        self.checkSpecificToken("symbol", "{")

        self.get_next_token()
        while (self.j.token_type() == "keyword" and self.current_token == "var"):
            self.CompileVarDec()

        self.CompileStatements()

        self.checkSpecificToken("symbol", "}")

        self.scope_counter -= 1
        self.write_title_to_file("/subroutineBody")
        self.get_next_token()


    def CompileVarDec(self):
        self.write_title_to_file("varDec")
        self.scope_counter += 1
        self.write_to_file()

        self.get_next_token()
        self.handleType()

        self.get_next_token()
        if (self.j.token_type() == "identifier"):
            self.write_to_file()

        self.get_next_token()
        while (self.j.token_type() == "symbol" and self.current_token== ","):
            self.write_to_file()
            self.get_next_token()
            if (self.j.token_type() == "identifier"):
                self.write_to_file()
            self.get_next_token()

        self.checkSpecificToken("symbol", ";")

        self.scope_counter -= 1
        self.write_title_to_file("/varDec")
        self.get_next_token()


    def CompileStatements(self):
        self.write_title_to_file("statements")
        self.scope_counter += 1

        while (self.j.token_type() == "keyword" and (self.current_token in statementSet)):
            if (self.j.token_type() == "keyword" and self.current_token == "let"):
                self.CompileLet()

            elif (self.j.token_type() == "keyword" and self.current_token == "if"):
                self.CompileIf()

            elif (self.j.token_type() == "keyword" and self.current_token == "while"):
                self.CompileWhile()

            elif (self.j.token_type() == "keyword" and self.current_token == "do"):
                self.CompileDo()

            elif (self.j.token_type() == "keyword" and self.current_token == "return"):
                self.CompileReturn()

        self.scope_counter -= 1
        self.write_title_to_file("/statements")


    def CompileLet(self):
        self.write_title_to_file("letStatement")
        self.scope_counter += 1
        self.write_to_file()

        self.get_next_token()
        if (self.j.token_type() == "identifier"):
            self.write_to_file()

        self.get_next_token()
        if (self.j.token_type() == "symbol" and self.current_token == "["):
            self.write_to_file()
            self.get_next_token()
            self.CompileExpression()
            if (self.j.token_type() == "symbol" and self.current_token == "]"):
                self.write_to_file()
            self.get_next_token()

        self.checkSpecificToken("symbol", "=")
        self.get_next_token()
        self.CompileExpression()
        self.checkSpecificToken("symbol", ";")

        self.get_next_token()
        self.scope_counter -= 1
        self.write_title_to_file("/letStatement")


    def CompileIf(self):
        self.write_title_to_file("ifStatement")
        self.scope_counter += 1
        self.write_to_file()

        self.get_next_token()
        self.checkSpecificToken("symbol", "(")
        self.get_next_token()
        self.CompileExpression()
        self.checkSpecificToken("symbol", ")")

        self.get_next_token()
        self.checkSpecificToken("symbol", "{")
        self.get_next_token()
        self.CompileStatements()
        self.checkSpecificToken("symbol", "}")

        self.get_next_token()
        if (self.j.token_type() == "keyword" and self.current_token == "else"):
            self.write_to_file()
            self.get_next_token()
            self.checkSpecificToken("symbol", "{")
            self.get_next_token()
            self.CompileStatements()
            self.checkSpecificToken("symbol", "}")

            self.get_next_token()

        self.scope_counter -= 1
        self.write_title_to_file("/ifStatement")


    def CompileWhile(self):
        self.write_title_to_file("whileStatement")
        self.scope_counter += 1
        self.write_to_file()

        self.get_next_token()

        self.checkSpecificToken("symbol", "(")
        self.get_next_token()
        self.CompileExpression()
        self.checkSpecificToken("symbol", ")")

        self.get_next_token()
        self.checkSpecificToken("symbol", "{")
        self.get_next_token()
        self.CompileStatements()
        self.checkSpecificToken("symbol", "}")

        self.get_next_token()
        self.scope_counter -= 1
        self.write_title_to_file("/whileStatement")


    def CompileDo(self):
        self.write_title_to_file("doStatement")
        self.scope_counter += 1
        self.write_to_file()

        self.get_next_token()
        if (self.j.token_type() == "identifier"):
            self.write_to_file()
            self.get_next_token()
            self.handleSubroutineCall()
            self.get_next_token()

        self.checkSpecificToken("symbol", ";")

        self.get_next_token()
        self.scope_counter -= 1
        self.write_title_to_file("/doStatement")


    def CompileReturn(self):
        self.write_title_to_file("returnStatement")
        self.scope_counter += 1
        self.write_to_file()

        self.get_next_token()
        if (not (self.j.token_type() == "symbol" and self.current_token == ";")):
            self.CompileExpression()

        self.checkSpecificToken("symbol", ";")

        self.get_next_token()
        self.scope_counter -= 1
        self.write_title_to_file("/returnStatement")


    def CompileExpression(self):
        self.write_title_to_file("expression")
        self.scope_counter += 1

        self.CompileTerm()

        while (self.j.token_type() == "symbol" and (self.current_token in opSet)):
            self.write_to_file()
            self.get_next_token()
            self.CompileTerm()

        self.scope_counter -= 1
        self.write_title_to_file("/expression")


    def CompileTerm(self):
        self.write_title_to_file("term")
        self.scope_counter += 1

        ## if the token is an int, a string, a keyword or an unaryOp:
        if (self.j.token_type() == "integerConstant" or
                    self.j.token_type() == "stringConstant" or
                    self.j.token_type() == "keyword"):
            self.write_to_file()
            self.get_next_token()
        ## if the token is a an exression in paranethesis:
        elif (self.j.token_type() == "symbol" and self.current_token == "("):
            self.write_to_file()
            self.get_next_token()
            self.CompileExpression()
            self.checkSpecificToken("symbol", ")")
            self.get_next_token()

        elif (self.j.token_type() == "identifier"):
            self.write_to_file()
            self.get_next_token()
            if (self.j.token_type() == "symbol" and self.current_token == "["):
                self.write_to_file()
                self.get_next_token()
                self.CompileExpression()
                self.checkSpecificToken("symbol", "]")
                self.get_next_token()

            elif (self.j.token_type() == "symbol" and (self.current_token == "("
                   or self.current_token == "." )):
                self.handleSubroutineCall()
                self.get_next_token()

        elif (self.j.token_type() == "symbol" and (self.current_token in unaryOpSet)):
            self.write_to_file()
            self.get_next_token()
            self.CompileTerm()

        self.scope_counter -= 1
        self.write_title_to_file("/term")


    def handleSubroutineCall(self):
        if (self.current_token == "("):
            self.handleExpressionListCall()

        elif (self.current_token == "."):
            self.write_to_file()
            self.get_next_token()
            if (self.j.token_type() == "identifier"):
                self.write_to_file()
                self.get_next_token()
                self.handleExpressionListCall()


    def handleExpressionListCall(self):
        if (self.current_token == "("):
            self.write_to_file()
            self.get_next_token()
            if (self.j.token_type() == "symbol" and self.current_token == ")"):
                self.CompileExpressionList(True)
                self.write_to_file()
            else:
                self.CompileExpressionList(False)
                if (self.j.token_type() == "symbol" and self.current_token == ")"):
                    self.write_to_file()


    def CompileExpressionList(self, zeroArguments):
        self.write_title_to_file("expressionList")
        self.scope_counter += 1

        if (not zeroArguments):
            self.CompileExpression()
            while (self.j.token_type() == "symbol" and self.current_token == ","):
                self.write_to_file()
                self.get_next_token()
                self.CompileExpression()

        self.scope_counter -= 1
        self.write_title_to_file("/expressionList")





