import re

import sys

import os


class JackTokenizer:

    keyword_set = {"class", "constructor", "function", "method", "field", "static",
                   "var", "int", "char", "boolean", "void", "true", "false", "null",
                   "this", "let", "do", "if", "else", "while", "return"}

    symbol_set = {"{", "}", "(", ")", "[", "]", ".", ",", ";", "+", "-", "*", "/",
                 "&", "|", ">", "<", "=", "~"}

    in_comment_line_flag = False

    identifier_regex = re.compile('[_a-zA-Z][_\w]*')
    string_regex = re.compile('".*?"')
    int_regex = re.compile('[0-9]+')
    comment_regex = re.compile('//.*')
    end_of_comment_regex = re.compile('.*?\*/')

    def __init__(self, input_file):
        self.tokens = []
        self.regex_array = [self.int_regex, self.string_regex, self.identifier_regex]
        self.parse_file(input_file)
        self.token_counter = -1

    def advance(self):
        self.token_counter += 1

    def has_more_tokens(self):
        return ((self.token_counter != len(self.tokens)))

    def token_type(self):
        return self.tokens[self.token_counter][1]

    def keyword(self):
        return self.tokens[self.token_counter][0]

    def symbol(self):
        return self.tokens[self.token_counter][0]

    def identifier(self):
        return self.tokens[self.token_counter][0]

    def int_val(self):
        return int(self.tokens[self.token_counter][0])

    def string_val(self):
        return (self.tokens[self.token_counter][0])[1:-1]

    def parse_file(self, input_file):
        with open(input_file) as file_lines:
            for line in file_lines:
                line = line.strip()
                self.parse_line(line.strip())

    def parse_line(self, line):
        """
        parses a single .vm line
        :param line: a line of the .vm file
        """
        if line.startswith("//") or line == '' or line == "\n":
            return
        while (line != ""):
            line = line.strip()
            if ((line.startswith("/**") or line.startswith("/*"))
                and self.in_comment_line_flag == False):
                self.in_comment_line_flag = True
            if (self.in_comment_line_flag):
                m = self.end_of_comment_regex.match(line)
                if (m != None):
                    line = line[m.end():]
                    self.in_comment_line_flag = False
                    continue
                else:
                    return
            m = self.comment_regex.match(line)
            if (m != None):
                return

            for regex in self.regex_array:
                m = regex.match(line)
                if (m != None):
                    end = m.end()
                    self.tokens.append((m.group(),self.get_regex_type(regex,m.group())))
                    if (end < len(line)):
                        line = line[end:]
                        break
                    else:
                        return
            else:
                if (line[0] in self.symbol_set):
                    symbol = line[0]
                    if (line[0] == "<"):
                        symbol = "&lt;"
                    elif (line[0] == ">"):
                        symbol = "&gt;"
                    elif (line[0] == "&"):
                        symbol = "&amp;"
                    elif (line[0] == '"'):
                        symbol = "&quot;"
                    self.tokens.append((symbol, "symbol"))
                    line = line[1:]
                    continue


    def get_regex_type(self, regex, token):
        if (regex == self.regex_array[0]):
            return "integerConstant"
        if (regex == self.regex_array[1]):
            return "stringConstant"
        if (regex == self.regex_array[2]):
            if (token in self.keyword_set):
                return "keyword"
            return "identifier"



# def main():
#     path = sys.argv[1]
#     j = JackTokenizer(path)
#     fileName = path.strip("jack") + "HUHU..xml"
#     output = open(fileName, "w+")
#     token = None
#     output.write("<" + "tokens" + ">\n")
#     while (j.has_more_tokens()):
#         cur_type = j.token_type()
#         if (cur_type is "keyword"):
#             token = j.keyword()
#         if (cur_type is "symbol"):
#             token = j.symbol()
#         if (cur_type is "identifier"):
#             token = j.identifier()
#         if (cur_type is "integerConstant"):
#             token = j.int_val()
#         if (cur_type is "stringConstant"):
#             token = j.string_val()
#         output.write("<" + cur_type + "> " + str(token) + " <" + "/" + cur_type + ">\n")
#         j.advance()
#     output.write("<" + "tokens" + ">\n")

#
# if __name__ == "__main__":
#     main()