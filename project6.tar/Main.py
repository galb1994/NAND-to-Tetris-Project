import sys
import re
import os

INVALID_SYMBOL_REGEX = '^[0-9]+$'
MEMORY_ALLOCATION_START = 16
FILE_BEGINNING = 0

def clearLine(line):
    line = "".join(line.split())
    if line == "" or line.startswith("//"):
        return ""
    line = line.split("//")
    return line[0]


def firstPass(fileLines, symbolDict):
    lineCounter = 0
    for line in fileLines:
        line = clearLine(line)
        if line == "":
            continue
        if line.startswith("(") and line.endswith(")"):
            handleLabel(line,symbolDict, lineCounter)
            continue
        lineCounter += 1


def secondPass(fileLines, symbolDict):
    symbolCounter = 0
    for line in fileLines:
        line = clearLine(line)
        if line == "":
            continue
        if line.startswith("@"):
            symbolCounter = handleSymbol(line[1:], symbolDict, symbolCounter)


def handleSymbol(line, symbolDict, symbolCounter):
    if line in symbolDict:
        return symbolCounter
    p = re.compile(INVALID_SYMBOL_REGEX)
    m = p.match(line)
    if m != None:
        return symbolCounter
    symbolDict[line] = str(symbolCounter + MEMORY_ALLOCATION_START)
    return symbolCounter + 1


def handleLabel(line, symbolDict, lineCounter):
    symbolDict[line.strip("(").strip(")")] = str(lineCounter)


def parseFile(filePath):
    compDict = {"0": "110101010", "1": "110111111", "-1": "110111010",
                "D": "110001100",
                "A": "110110000", "M": "111110000", "!D": "110001101",
                "!A": "110110001",
                "!M": "111110001", "-D": "110001111", "-A": "110110011",
                "-M": "111110011",
                "D+1": "110011111", "A+1": "110110111", "M+1": "111110111",
                "D-1": "110001110",
                "A-1": "110110010", "M-1": "111110010", "D+A": "110000010",
                "D+M": "111000010",
                "D-A": "110010011", "D-M": "111010011", "A-D": "110000111",
                "M-D": "111000111",
                "D&A": "110000000", "D&M": "111000000", "D|A": "110010101",
                "D|M": "111010101",
                "D<<": "010110000", "A<<": "010100000", "M<<": "011100000",
                "D>>": "010010000", "A>>": "010000000", "M>>": "011000000"}

    symbolDict = {"R0": "0", "R1": "1", "R2": "2", "R3": "3", "R4": "4",
                  "R5": "5",
                  "R6": "6", "R7": "7", "R8": "8", "R9": "9", "R10": "10",
                  "R11": "11",
                  "R12": "12", "R13": "13", "R14": "14", "R15": "15",
                  "SCREEN": "16384",
                  "KBD": "24576", "SP": "0", "LCL": "1", "ARG": "2",
                  "THIS": "3",
                  "THAT": "4"}
    with open(filePath) as fileLines:
        firstPass(fileLines, symbolDict)
        fileLines.seek(FILE_BEGINNING)
        secondPass(fileLines, symbolDict)
        fileLines.seek(FILE_BEGINNING)
        lines = []
        for line in fileLines:
            line = clearLine(line)
            if line == "" or (line.startswith("(") and line.endswith(")")):
                continue
            if line.startswith("@"):
                binaryInstruction = handleAOperation(line[1:],symbolDict)
            else:
                binaryInstruction = handleCOperation(line,compDict)
            lines.append(binaryInstruction)
        return lines


def handleAOperation(line, symbolDict):
    if line in symbolDict:
        line = symbolDict[line]
    operation = '{0:b}'.format(int(line))
    operation = str(operation)
    for i in range(15 - len(operation)):
        operation = "0" + operation
    return '0' + operation


def handleCOperation(line, compDict):
    dest, comp, jump = "", "", ""
    if "=" in line:
        dest, compAndJump = line.split("=")
    else:
        compAndJump = line
    if ";" in line:
        comp, jump = compAndJump.split(";")
    else:
        comp = compAndJump
    return "1" + handleComp(comp, compDict) + handleDest(dest) + handleJump(jump)


def handleDest(dest):
    d1, d2, d3 = "0", "0", "0"
    if "A" in dest:
        d1 = "1"

    if "D" in dest:
        d2 = "1"

    if "M" in dest:
        d3 = "1"

    return d1 + d2 + d3


def handleJump(jump):
    j1, j2, j3 = "0", "0", "0"
    if (jump == "JLT") or (jump == "JNE") or (jump == "JLE") or (
        jump == "JMP"):
        j1 = "1"
    if (jump == "JEQ") or (jump == "JGE") or (jump == "JLE") or (
        jump == "JMP"):
        j2 = "1"
    if (jump == "JGT") or (jump == "JGE") or (jump == "JNE") or (
        jump == "JMP"):
        j3 = "1"
    return j1 + j2 + j3


def handleComp(comp, compDict):
    return compDict[comp]


def handleSingleFile(path):
    fileName = path.strip(".asm") + ".hack"
    output = open(fileName, "w+")
    lines = parseFile(path)
    for line in lines:
        output.write(line + "\n")


def main():
    path = sys.argv[1]
    if not os.path.isdir(path):
        handleSingleFile(path)
    else:
        files = [file for file in os.listdir(path)]
        for file in files:
            if not file.endswith(".asm"):
                continue
            handleSingleFile(path + "/" + file)


if __name__ == "__main__":
    main()
