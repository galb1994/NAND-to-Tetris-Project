import sys
import os
from parser import Parser
from codeWriter import CodeWriter


def handleSingleFile(current_file_path, output_lines, current_file_name):
    """
    handles a single .vm file
    :param current_file_path: the path of the current .vm file
    :param output_lines: a list of output lines
    :param current_file_name: the name of the current file - used for 'static'
    :return:
    """
    p = Parser(current_file_path)
    lines = p.parse_file()
    writer = CodeWriter(lines, output_lines, current_file_name)
    writer.writeAllCommands()

def main():
    """
    the main functions - running this program and translates .vm files to
     a.asm file.
    :return:
    """
    output_lines = []
    path = sys.argv[1]
    if not os.path.isdir(path):
        asm_file_name = path.strip("vm") + "asm"
        asm_file = open(asm_file_name, "w")
        handleSingleFile(path,output_lines, os.path.basename(path))
    else:
        files = [file for file in os.listdir(path)]
        asm_file_name = path + ".asm"
        asm_file = open(asm_file_name, "w")
        for file in files:
            if not file.endswith(".vm"):
                continue
            current_file_name = os.path.basename(file)
            handleSingleFile(path + "//" + file, output_lines, current_file_name)
    for line in output_lines:
        asm_file.write(line + "\n")
        print(line)


if __name__ == "__main__":
    main()