class Parser:
    """
    this class is used in order to parse the lines of a .vm file
    """

    def __init__(self, file_path):
        """
        initializes a Parser object.
        :param file_path: the file_path of the .vm file
        """
        self.path = file_path

    def parse_line(self, line):
        """
        parses a single .vm line
        :param line: a line of the .vm file
        """
        line.strip(" ") #If line is a whitespace, it'll become ''
        if line.startswith("//") or line == '' or line == "\n":
            return ''
        return line.split()

    def parse_file(self):
        """
        parses an entire .vm file.
        :return: a list of parsed lines.
        """
        with open(self.path) as fileLines:
            lines = []
            for line in fileLines:
                line = self.parse_line(line)
                if line == '':
                    continue
                lines.append(line)
            return lines


