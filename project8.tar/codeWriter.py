class CodeWriter:
    """
    this class is used to translate .vm command to .asm commands.
    """
    # this translates the given segment name to its index in the RAM.
    segment_dict = {"sp": "0", "local": "1", "argument": "2", "pointer": "3",
                    "this": "3", "that": "4", "temp": "5", "static": "16"}
    # counts the number of labels used, in order to have unique label names.
    label_counter = 0
    # same as label_counter
    end_label_counter = 0
    # same as the previous counters
    comparison_counter = 0
    VM_line_counter = 0

    def __init__(self, parsed_lines, output_lines, current_file_name):
        """
        initializes a codeWriter object
        :param parsed_lines: a list of parsed .vm commands
        :param output_lines: a list of output lines to which we will append the
         .asm commands.
        :param current_file_name: the name of the .vm file.
        """
        self.parsed_lines = parsed_lines
        self.output_lines = output_lines
        self.current_file_name = current_file_name

    def writeAllCommands(self):
        """
        translates all the commands in the given parsed_lined and appends them
         to output_lines.
        :return:
        """
        if self.output_lines == []:
            self.writeInit()
        for line in self.parsed_lines:
            self.writeSingleCommand(line)

    def writeSingleCommand(self, line):
        """
        translates a single .vm commands to a .asm command, and appends it to
         output_lines.
        :param line: a single .vm parsed line (given as a list)
        """
        operation = line[0]

        self.writeCommandComment(line)
        if operation == "push":
            self.writePushOperation(line)

        elif operation == "pop":
            self.writePopOperation(line)

        elif operation == "add":
            self.writeAddOperation()

        elif operation == "sub":
            self.writeSubOperation()

        elif operation == "neg":
            self.writeNegOperation()

        elif operation == "eq":
            self.writeEqualOperation()

        elif operation == "gt":
            self.writeGreaterThanOperation()

        elif operation == "lt":
            self.writeLowerThanOperation()

        elif operation == "and":
            self.writeAndOperation()

        elif operation == "or":
            self.writeOrOperation()

        elif operation == "not":
            self.writeNotOperation()

        elif operation == "label":
            self.writeLabel(line)

        elif operation == "goto":
            self.writeGoToJump(line)

        elif operation == "if-goto":
            self.writeConditionalJump(line)

        elif operation == "call":
            self.writeFunctionCall(line)

        elif operation == "function":
            self.WriteFunction(line)

        elif operation == "return":
            self.WriteReturn(line)

        CodeWriter.VM_line_counter += 1

    # region Basic stack manipulations
    def writeStackToD(self):
        """
        appends the appropriate commands in order to pop the top value of the
         stack to D.
        """
        # Pops the next element on the stack and puts it in D
        self.decrementStackPointer()
        self.pointToStack()
        self.output_lines.append("D=M")

    def writeDToStack(self):
        """
        appends the appropriate commands in order to write D the the top of
         the stack.
        """

        # Pushes D to the stack
        self.pointToStack()
        self.output_lines.append("M=D")
        self.incrementStackPointer()

    def moveValue(self, segment, value):
        """
        calculates the determinant of ex6 and writes it to the stack
        :param segment: the given segment of the memory
        :param value: the index in the given segment
        """
        if segment == "temp":
            self.handleTemp(value)
            return
        self.output_lines.append('')
        if segment == "constant":
            self.output_lines.append("@" + str(value))
        else:
            # D -> R15
            self.output_lines.append("@R15")
            self.output_lines.append("M=D")

            # value -> D
            self.output_lines.append("@" + str(value))
            self.output_lines.append("D=A")
            self.output_lines.append("@" + self.segment_dict[segment])
            if segment == "pointer":
                self.output_lines.append("A=D+A")
            else:
                # address -> R14
                self.output_lines.append("D=D+M")
                self.output_lines.append("@R14")
                self.output_lines.append("M=D")

                # Puts the value that we wanted to put in the segment in D
                self.output_lines.append("@R15")
                self.output_lines.append("D=M")

                # address -> A
                self.output_lines.append("@R14")
                self.output_lines.append("A=M")

                # value -> segment
                self.output_lines.append("M=D")

            self.output_lines.append("@R15")
            self.output_lines.append("D=M")

    def writeValueTo(self, segment, value):
        """
        writes the value in D the the given place in memory.
        :param segment:
        :param value:
        """
        self.keepDAside()
        self.pointTo(segment, value)
        self.keepAaside()
        self.getDFromR15()
        self.getAFromR14()
        # self.moveValue(segment, value)
        self.output_lines.append("M=D")

    def writeValueToStack(self, value):
        """
        writes a given value to the top of the stack.
        :param value: given value - must be positive!
        """
        self.output_lines.append("@" + str(value))
        # ONLY POSITIVE VALUES!!!!
        self.output_lines.append("D=A")
        self.writeDToStack()

    def decrementStackPointer(self):
        """
        decrements the stack pointer
        """
        self.output_lines.append('')
        self.output_lines.append("@" + self.segment_dict["sp"])
        self.output_lines.append("M=M-1")

    def incrementStackPointer(self):
        """
        increments the stack pointer
        """
        self.output_lines.append('')
        self.output_lines.append("@" + self.segment_dict["sp"])
        self.output_lines.append("M=M+1")

    def pointToStack(self):
        """
        points to the stack
        """
        self.output_lines.append('')
        self.output_lines.append("@" + self.segment_dict["sp"])
        self.output_lines.append("A=M")

    def pointTo(self, segment, value):
        """
        makes A point to the specified place in memory
        :param segment: the segment in memory
        :param value: the index in the segment
        """
        self.output_lines.append('')
        if segment == "pointer":
            # Make A pointing on the value'th element of the given segment
            self.output_lines.append(
                "@" + str(int(self.segment_dict[segment]) + int(value)))
            return

        if segment == "temp":
            self.handleTemp(value)
            return

        if segment == "constant":
            self.output_lines.append("@" + str(value))
            return

        if segment == "static":
            self.output_lines.append(
                "@" + self.current_file_name + "." + str(value))
            return

        # value -> D
        self.output_lines.append("@" + str(value))
        self.output_lines.append("D=A")

        # Make A pointing on the value'th element of the given segment
        self.output_lines.append("@" + self.segment_dict[segment])
        self.output_lines.append("A=D+M")

    def takeValueFrom(self, segment, value):
        """
        writes the value in the specified place in the memory to D.
        :param segment: the segment of the memory
        :param value: the index in the segment
        """
        self.pointTo(segment, value)
        if segment == "constant":
            self.output_lines.append("D=A")

        else:
            self.output_lines.append("D=M")

    def keepAaside(self):
        """
        keeps the value of A aside
        """
        self.output_lines.append("D=A")
        self.output_lines.append("@R14")
        self.output_lines.append("M=D")

    def getDFromR15(self):
        """
        gets the value of D from R15
        """
        self.output_lines.append("@R15")
        self.output_lines.append("D=M")

    def keepDAside(self):
        """
        keeps the value of D aside
        """
        self.output_lines.append("@R15")
        self.output_lines.append("M=D")

    def getAFromR14(self):
        """
        gets A from from A14
        """
        self.output_lines.append("@R14")
        self.output_lines.append("A=M")
    # endregion

    # region Arithmetic operations
    def writeAddOrSubOperation(self, command):
        """
        writes a Sub or Add Operation
        :param command: should be an assembly command representing addition or
         substraction.
        """
        # Puts the first element in D
        self.writeStackToD()

        # Gets the stack to point on the next element, and puts the
        # result of the arithmetic operation in D
        self.decrementStackPointer()
        self.pointToStack()
        self.output_lines.append(command)

        # puts D in the stack
        self.writeDToStack()

    def writeAddOperation(self):
        """
        writes a single Add operation
        """
        self.writeAddOrSubOperation("D=D+M")

    def writeSubOperation(self):
        """
        writes a single Sub operation
        """
        self.writeAddOrSubOperation("D=M-D")

    # endregion

    # region Bitwise operations
    def writeBitwiseOperation(self, bitwise):
        """
        writes a single bitwise operation.
        :param bitwise: the appropriate command for the specified Bitwise
         operation.
        """
        self.writeStackToD()

        # Pops the next element on the stack and puts the required bitwise
        # between D and M inside D
        self.decrementStackPointer()
        self.pointToStack()
        self.output_lines.append(bitwise)

        # Puts D in the stack
        self.writeDToStack()

    def writeNegOperation(self):
        """
        writes a single Neg operation
        """
        self.decrementStackPointer()
        self.pointToStack()
        self.output_lines.append("M=-M")
        self.incrementStackPointer()

    def writeAndOperation(self):
        """
        writes a Bitwise And operation.
        """
        self.writeBitwiseOperation("D=D&M")

    def writeOrOperation(self):
        """
        writes a Bitwise Or operation
        """
        self.writeBitwiseOperation("D=D|M")

    def writeNotOperation(self):
        """
        writes a Not operation
        """
        self.decrementStackPointer()
        self.pointToStack()
        self.output_lines.append("M=!M")
        self.incrementStackPointer()

    # endregion

    # region Comparison operations
    def writeCompareOperation(self, condition):
        """compares the top two values on the stack, using the given condition"""
        self.writeSubOperation()

        # Puts the result in D, then checks if D matches condition
        self.writeStackToD()
        self.pointToNextLabel()
        self.output_lines.append(condition)

        self.writeValueToStack(0)  # false
        self.pointToNextEndLabel()
        self.output_lines.append("0;JMP")

        self.writeNextLabel()
        self.output_lines.append("D=-1")  # true
        self.writeDToStack()

        self.writeNextEndLabel()

    def compare(self, condition, jumpOperation):
        """
        writes a compare operation, according to the given parameters.
        :param condition: EQ / LT / GT
        :param jumpOperation: the .asm command appropriate to the condition.
        """
        # y -> D
        self.output_lines.append(
            "(" + "compare" + str(CodeWriter.comparison_counter) + ")")
        self.writeStackToD()
        self.output_lines.append(
            "@YPositive" + str(CodeWriter.comparison_counter))
        self.output_lines.append("D;JGE")

        # D -> R13
        self.output_lines.append("@R13")
        self.output_lines.append("M=D")

        # x -> D
        self.writeStackToD()

        self.output_lines.append(
            "@YNegativeXPositive" + str(CodeWriter.comparison_counter))
        self.output_lines.append("D;JGE")

        # If x and y have the same sign, goto SameSign
        self.output_lines.append(
            "@SameSign" + str(CodeWriter.comparison_counter))
        self.output_lines.append("0;JMP")

        # When x is positive, we check if y is negative:
        self.output_lines.append(
            "(YPositive" + str(CodeWriter.comparison_counter) + ")")
        self.output_lines.append("@R13")
        self.output_lines.append("M=D")
        # x -> D
        self.writeStackToD()
        # x is negative:
        self.output_lines.append(
            "@YPositiveXNegative" + str(CodeWriter.comparison_counter))
        self.output_lines.append("D;JLT")

        # If x and y have the same sign, goto SameSign
        self.output_lines.append(
            "@SameSign" + str(CodeWriter.comparison_counter))
        self.output_lines.append("0;JMP")

        self.output_lines.append(
            "(SameSign" + str(CodeWriter.comparison_counter) + ")")
        # x -> stack
        self.writeDToStack()
        self.output_lines.append("@R13")
        self.output_lines.append("D=M")
        # y -> stack
        self.writeDToStack()
        # x and y have the same sign, so we subtract one from another
        self.writeCompareOperation(jumpOperation)

        # goto ENDCompare
        self.output_lines.append(
            "@ENDCompare" + str(CodeWriter.comparison_counter))
        self.output_lines.append("0;JMP")

        self.output_lines.append(
            "(YPositiveXNegative" + str(CodeWriter.comparison_counter) + ")")
        if condition == "GT" or condition == "EQ":
            self.writeValueToStack(0)
            self.output_lines.append(
                "@ENDCompare" + str(CodeWriter.comparison_counter))
            self.output_lines.append("0;JMP")
        elif condition == "LT":
            self.output_lines.append("D=-1")
            self.writeDToStack()
            self.output_lines.append(
                "@ENDCompare" + str(CodeWriter.comparison_counter))
            self.output_lines.append("0;JMP")

        self.output_lines.append(
            "(YNegativeXPositive" + str(CodeWriter.comparison_counter) + ")")
        if condition == "GT":
            self.output_lines.append("D=-1")
            self.writeDToStack()
            self.output_lines.append(
                "@ENDCompare" + str(CodeWriter.comparison_counter))
            self.output_lines.append("0;JMP")
        elif condition == "LT" or condition == "EQ":
            self.writeValueToStack(0)
            self.output_lines.append(
                "@ENDCompare" + str(CodeWriter.comparison_counter))
            self.output_lines.append("0;JMP")

        self.output_lines.append(
            "(ENDCompare" + str(CodeWriter.comparison_counter) + ")")

        CodeWriter.comparison_counter += 1

    def writeGreaterThanOperation(self):
        """
        writes a GT operation
        """
        self.compare("GT", "D;JGT")

    def writeEqualOperation(self):
        """
        writes a EQ operation
        """
        self.compare("EQ", "D;JEQ")

    def writeLowerThanOperation(self):
        """
        writes a LT operation
        """
        self.compare("LT", "D;JLT")

    def writeNextLabel(self):
        """
        writes the next unique label
        """
        self.output_lines.append(
            "(LABEL" + str(CodeWriter.label_counter) + ")")
        CodeWriter.label_counter += 1

    def pointToNextLabel(self):
        """
        points to the next label
        """
        self.output_lines.append("@LABEL" + str(CodeWriter.label_counter))

    def writeNextEndLabel(self):
        """
        writes the next unique end label
        """
        self.output_lines.append(
            "(END" + str(CodeWriter.end_label_counter) + ")")
        CodeWriter.end_label_counter += 1

    def pointToNextEndLabel(self):
        """
        points to the next end label
        """
        self.output_lines.append("@END" + str(CodeWriter.end_label_counter))

    # endregion

    # region Push & Pop operations
    def writePushOperation(self, line):
        """
        writes a Push operation
        :param line: the parsed .vm command
        """
        segment = line[1]
        value = line[2]
        self.takeValueFrom(segment, value)
        self.writeDToStack()

    def writePopOperation(self, line):
        """
        writes a Pop operation
        :param line: the parsed .vm command
        """
        segment = line[1]
        value = line[2]
        self.writeStackToD()
        self.writeValueTo(segment, value)

    # endregion

    def handleTemp(self, value):
        """
        handles a command containing the temp segment
        :param value: the index in the temp segment
        """
        self.output_lines.append(
            "@" + str(int(self.segment_dict["temp"]) + int(value)))

    def writeCommandComment(self, line):
        """
        writes a comment line, which helps debugging and reading the .asm file.
        :param line: a parsed .vm line
        """
        self.output_lines.append('')
        comment_string = "// "
        for word in line:
            comment_string += str(word) + " "
        self.output_lines.append(comment_string)

    def writeLabel(self, line):
        """
        writes a label for a given "label" command of a .vm file
        :param line: a parsed .vm line
        """
        self.output_lines.append(
            "(" + self.current_file_name + "." + line[1] + ")")

    def writeConditionalJump(self, line):
        """
        writes an "@X, D;JNE" command in assmebly, which represents an "if-goto"
        vm command
        :param line: a parsed .vm line
            """
        # if counter != 0, jump to the given label
        self.writeStackToD()
        self.output_lines.append("@" + self.current_file_name + "." + line[1])
        self.output_lines.append("D;JNE")

    def writeGoToJump(self, line):
        """
        writes an "@X, 0;JMP" command in assmebly, which represents a "goto"
        vm command
        :param line: a parsed .vm line
            """
        self.output_lines.append("@" + self.current_file_name + "." + line[1])
        self.output_lines.append("0;JMP")

    def writeUnConditionalJump(self, line):
        """
        writes an "@X, 0;JMP" command in assmebly, which represents an "if-goto"
        vm command (used by the "writeFunctionCall" method)
        :param line: a parsed .vm line
            """
        self.output_lines.append("@" + line[1])
        self.output_lines.append("0;JMP")

    def saveCallerSegment(self, segment):
        """
        pushes the address of the given segment into the stack
        :param segment: a segment that we currently want to save by pushing
        into the stack
            """
        self.output_lines.append("@" + self.segment_dict[segment])
        self.output_lines.append("D=M")
        self.writeDToStack()

    def writeFunctionCall(self, line):
        """
        writes a call to a function in assembly.
        First, we mark the place in the asm file that we'd like to jump back
        when the function's operations end.
        Secondly, we keep all the current scope's variables aside.
        Then we jump to the part in the asm code that executes the called
        function's operations
        :param line: a parsed .vm line
            """
        # Pushes return address
        self.output_lines.append(
            "@returnAddress" + "." + str(CodeWriter.VM_line_counter))
        self.output_lines.append("D=A")
        self.writeDToStack()

        # Saves the caller's segments
        self.saveCallerSegment("local")
        self.saveCallerSegment("argument")
        self.saveCallerSegment("this")
        self.saveCallerSegment("that")

        # SP -> D
        self.output_lines.append("@0")
        self.output_lines.append("D=M")

        # SP-5-nArgs -> D
        self.output_lines.append("@5")
        self.output_lines.append("D=D-A")
        self.output_lines.append("@" + line[2])
        self.output_lines.append("D=D-A")

        # D -> ARG
        self.output_lines.append("@" + self.segment_dict["argument"])
        self.output_lines.append("M=D")

        # Top of the stack -> LCL
        self.output_lines.append("@0")
        self.output_lines.append("D=M")
        self.output_lines.append("@" + self.segment_dict["local"])
        self.output_lines.append("M=D")

        # goto the given function name
        self.writeUnConditionalJump(line)

        # Return address' label
        self.output_lines.append("(" + "returnAddress" + "." + str(
            CodeWriter.VM_line_counter) + ")")


    def WriteFunction(self, line):
        """
        writes a function in assembly.
        :param line: a parsed .vm line
            """
        if line[1] == "Sys.init":
            self.output_lines.append("(" + line[1] + ")")
        else:
            self.output_lines.append("(" + line[1] + ")")

        # if the function is from the type " function X 0", there are no local
        #  variables to initialize
        if int(line[2]) != 0:
            self.output_lines.append("@" + self.segment_dict["local"])
            self.output_lines.append("A=M")
            for i in range(int(line[2])):
                self.output_lines.append("M=0")
                self.output_lines.append("A=A+1")

            # Increments the SP pointer in the number of local variables of
            # the function
            self.output_lines.append("@0")
            for j in range(int(line[2])):
                self.output_lines.append("M=M+1")

    def restoreOneSegment(self, segment, num):
        """
        When gects back to the scope that called some function, sets the
        given segment to point to it's original place in the stack
        :param segment: the current segment we'd like to restore
        :param num: the number we decrease from the address that is kept in R15
        for pointing to the place in the stack that from which we'd like to
        get the given segment's original address
            """
        self.output_lines.append("@" + str(num))
        self.output_lines.append("D=A")
        self.output_lines.append("@R15")
        self.output_lines.append("A=M-D")
        self.output_lines.append("D=M")
        self.output_lines.append("@" + self.segment_dict[segment])
        self.output_lines.append("M=D")

    def WriteReturn(self, line):
        """
        writes a return from a function in assembly.
        Sets the stack back to it's state from before calling the function
        :param line: a parsed .vm line
            """
        # Puts "local"'s address in "endFrame" (actually in R15)
        self.output_lines.append("@" + self.segment_dict["local"])
        self.output_lines.append("D=M")
        self.output_lines.append("@R15")
        self.output_lines.append("M=D")

        # Puts the return address in retAddr (actually in R14)
        self.output_lines.append("@R15")
        self.output_lines.append("D=M")
        self.output_lines.append("@5")
        self.output_lines.append("D=D-A")
        self.output_lines.append("A=D")
        self.output_lines.append("D=M")
        self.output_lines.append("@R14")
        self.output_lines.append("M=D")

        # *ARG = pop(), puts the return value of the function in arg[0]
        self.writeStackToD()
        self.output_lines.append("@" + self.segment_dict["argument"])
        self.output_lines.append("A=M")
        self.output_lines.append("M=D")

        # Sets SP back in it's place
        self.output_lines.append("@" + self.segment_dict["argument"])
        self.output_lines.append("D=M+1")
        self.output_lines.append("@" + self.segment_dict["sp"])
        self.output_lines.append("M=D")

        # *(endFrame) - 1-> D, which means, putting "saved this" back in this
        self.restoreOneSegment("that", 1)

        # *(local[0]) - 2-> D, which means, putting "saved that" back in that
        self.restoreOneSegment("this", 2)

        # *(local[0]) - 3-> D, which means, putting "saved arg" back in arg
        self.restoreOneSegment("argument", 3)

        # *(local[0]) - 4-> D, which means, putting "saved local" back in local
        self.restoreOneSegment("local", 4)

        # goto
        self.output_lines.append("@R14")
        self.output_lines.append("A=M")
        self.output_lines.append("0;JMP")

    def writeInit(self):
        """
        writes the "Sys.init" function, which runs the whole program.
            """
        self.output_lines.append("@256")
        self.output_lines.append("D=A")
        self.output_lines.append("@0")
        self.output_lines.append("M=D")
        self.writeFunctionCall(["call", "Sys.init", "0"])
