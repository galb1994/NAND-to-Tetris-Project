class SymbolTable:

    TYPE_INDEX = 0
    KIND_INDEX = 1
    NUMBER_INDEX = 2

    def __init__(self):
        self.class_symbol_table = {}
        self.subroutine_symbol_table = {}
        self.field_counter = 0
        self.static_counter = 0
        self.arg_counter = 0
        self.var_counter = 0


    def startSubroutine(self):
        self.subroutine_symbol_table = {}
        self.arg_counter = 0
        self.var_counter = 0


    def define(self, name, type, kind):
        """
        :param name: A string
        :param type: A string
        :param kind: A string that has to be "STATIC", "FIELD", "ARG" or "VAR"
        :return:
        """
        if (kind == "STATIC"):
            self.class_symbol_table[name] = (type, kind, self.static_counter)
            self.static_counter += 1

        if (kind == "FIELD"):
            self.class_symbol_table[name] = (type, kind, self.field_counter)
            self.field_counter += 1

        if (kind == "ARG"):
            self.subroutine_symbol_table[name] = (type, kind, self.arg_counter)
            self.arg_counter += 1

        if (kind == "VAR"):
            self.subroutine_symbol_table[name] = (type, kind, self.var_counter)
            self.var_counter += 1


    def varCount(self, kind):
        if (kind == "STATIC"):
            return self.static_counter

        if (kind == "FIELD"):
            return self.field_counter

        if (kind == "ARG"):
            return self.arg_counter

        if (kind == "VAR"):
            return self.var_counter


    def kindOf(self, name):
        if (name in self.subroutine_symbol_table.keys()):
            return self.subroutine_symbol_table[name][self.KIND_INDEX]

        elif (name in self.class_symbol_table.keys()):
            return self.class_symbol_table[name][self.KIND_INDEX]

        else:
            return None


    def typeOf(self, name):
        if (name in self.subroutine_symbol_table.keys()):
            return self.subroutine_symbol_table[name][self.TYPE_INDEX]

        elif (name in self.class_symbol_table.keys()):
            return self.class_symbol_table[name][self.TYPE_INDEX]

        else:
            return None


    def indexOf(self, name):
        if (name in self.subroutine_symbol_table.keys()):
            return self.subroutine_symbol_table[name][self.NUMBER_INDEX]

        elif (name in self.class_symbol_table.keys()):
            return self.class_symbol_table[name][self.NUMBER_INDEX]

        else:
            return None