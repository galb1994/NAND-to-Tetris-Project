import sys

import os

import re

from JackTokenizer import JackTokenizer
from SymbolTable import SymbolTable
from VMWriter import VMWriter

opSet = {"+", "-", "*", "/", "&amp;", "|", "&lt;", "&gt;", "="}
unaryOpSet = {"-", "~"}
keyWordConstantSet = {"true", "false", "null", "this"}
statementSet = {"let", "if", "while", "do", "return"}


class CompilationEngine:

    def __init__(self, input_file, output_file):
        self.j = JackTokenizer(input_file)
        self.table = SymbolTable()
        self.writer = VMWriter(output_file)
        self.output = output_file
        self.current_token = None
        self.scope_counter = 0
        self.class_name = None
        self.condition_counter = 0
        self.loop_counter = 0


    def get_next_token(self):
        token = None
        if (self.j.has_more_tokens()):
            self.j.advance()
            cur_type = self.j.token_type()
            if (cur_type is "keyword"):
                token = self.j.keyword()
            if (cur_type is "symbol"):
                token = self.j.symbol()
            if (cur_type is "identifier"):
                token = self.j.identifier()
            if (cur_type is "integerConstant"):
                token = self.j.int_val()
            if (cur_type is "stringConstant"):
                token = self.j.string_val()
        self.current_token = token
        return token

    def checkSpecificToken(self, expectedTokenType, excpectedToken):

        if (self.j.token_type() == expectedTokenType and self.current_token == excpectedToken):
            pass


    def CompileClass(self):
        self.get_next_token()
        self.checkSpecificToken("keyword", "class")
        self.get_next_token()
        if (self.j.token_type() == "identifier"):
            pass

        self.class_name = self.current_token
        self.get_next_token()
        if (self.j.token_type() == "symbol" and self.current_token == "{"):
            pass

        self.get_next_token()
        while (self.j.token_type() == "keyword" and (self.current_token == "static" or
                                                     self.current_token == "field")):
            self.CompileClassVarDec()

        while (self.j.token_type() == "keyword" and (self.current_token == "constructor" or
                 self.current_token == "function" or self.current_token == "method")):
            self.CompileSubroutine(self.current_token)

        self.checkSpecificToken("symbol", "}")


    def CompileClassVarDec(self):
        self.scope_counter += 1
        var_kind = self.current_token
        self.get_next_token()
        var_type = self.current_token
        self.handleType()

        self.get_next_token()
        var_name = self.current_token
        if (self.j.token_type() == "identifier"):
            pass
        self.table.define(var_name, var_type, str(var_kind).upper())

        self.get_next_token()
        while (self.j.token_type() == "symbol" and self.current_token == ","):
            self.get_next_token()
            var_name = self.current_token
            self.table.define(var_name, var_type, str(var_kind).upper())
            if (self.j.token_type() == "identifier"):
                pass
            self.get_next_token()

        self.checkSpecificToken("symbol", ";")

        self.get_next_token()


    def CompileSubroutine(self, subroutine_type):
        self.table.startSubroutine()
        ## If the subroutine is a method, then "this" is argument 0, and all the
        ## parameters after that start at 1
        if (subroutine_type =="method"):
            self.table.arg_counter = 1
        self.get_next_token()
        if ((self.j.token_type() == "keyword" and (self.current_token == "int"
                   or self.current_token == "char" or self.current_token == "boolean"
                   or self.current_token == "void")) or self.j.token_type() == "identifier"):
            pass
        self.get_next_token()
        function_name = self.current_token

        if (self.j.token_type() == "identifier"):
            pass
        self.get_next_token()
        self.checkSpecificToken("symbol", "(")

        self.get_next_token()
        ## if the constructor/ function/ method has any parameters:
        if (self.j.token_type() == "symbol" and self.current_token == ")"):
            self.CompileParameterList(False)
        else:
            self.CompileParameterList(True)
        self.checkSpecificToken("symbol", ")")

        self.get_next_token()
        self.CompileSubroutineBody((self.class_name + "." + function_name), subroutine_type)


    def handleType(self):
        if ((self.j.token_type() == "keyword" and (self.current_token == "int" or
               self.current_token == "char" or self.current_token == "boolean"))
                or self.j.token_type() == "identifier"):
            pass


    def CompileParameterList(self, hasArguments):
        if (hasArguments):
            if ((self.j.token_type() == "keyword" and (self.current_token == "int" or self.current_token == "char" or
                self.current_token == "boolean")) or self.j.token_type() == "identifier"):
                argument_type = self.current_token

                self.get_next_token()
                argument_name = self.current_token
                self.table.define(argument_name, argument_type, "ARG")

                if (self.j.token_type() == "identifier"):
                    pass
                self.get_next_token()
                while (self.j.token_type() == "symbol" and self.current_token == ","):
                    self.get_next_token()
                    if ((self.j.token_type() == "keyword" and (
                            self.current_token == "int" or self.current_token == "char" or
                            self.current_token == "boolean")) or self.j.token_type() == "identifier"):
                        argument_type = self.current_token

                    self.get_next_token()
                    argument_name = self.current_token
                    self.table.define(argument_name, argument_type, "ARG")

                    if (self.j.token_type() == "identifier"):
                        pass
                    self.get_next_token()


    def CompileSubroutineBody(self, subroutine_title, subroutine_type):

        self.checkSpecificToken("symbol", "{")

        self.get_next_token()
        while (self.j.token_type() == "keyword" and self.current_token == "var"):
            self.CompileVarDec()

        self.writer.writeFunction(subroutine_title, self.table.var_counter)
        if (subroutine_type == "method"):
            self.writer.writePush("ARG", 0)
            self.writer.writePop("POINTER", 0)
        if (subroutine_type == "constructor"):
            self.writer.writePush("CONST", self.table.field_counter)
            self.writer.writeCall("Memory.alloc", 1)
            self.writer.writePop("POINTER", 0)
        self.CompileStatements()

        self.checkSpecificToken("symbol", "}")

        self.scope_counter -= 1
        self.get_next_token()


    def CompileVarDec(self):
        self.get_next_token()
        self.handleType()
        var_type = self.current_token

        self.get_next_token()
        var_name = self.current_token
        self.table.define(var_name, var_type, "VAR")
        if (self.j.token_type() == "identifier"):
            pass

        self.get_next_token()
        while (self.j.token_type() == "symbol" and self.current_token== ","):
            self.get_next_token()
            var_name = self.current_token
            self.table.define(var_name, var_type, "VAR")

            if (self.j.token_type() == "identifier"):
                pass
            self.get_next_token()

        self.checkSpecificToken("symbol", ";")
        self.get_next_token()


    def CompileStatements(self):
        while (self.j.token_type() == "keyword" and (self.current_token in statementSet)):
            if (self.j.token_type() == "keyword" and self.current_token == "let"):
                self.CompileLet()

            elif (self.j.token_type() == "keyword" and self.current_token == "if"):
                self.CompileIf()

            elif (self.j.token_type() == "keyword" and self.current_token == "while"):
                self.CompileWhile()

            elif (self.j.token_type() == "keyword" and self.current_token == "do"):
                self.CompileDo()

            elif (self.j.token_type() == "keyword" and self.current_token == "return"):
                self.CompileReturn()


    def CompileLet(self):

        self.get_next_token()
        var_name = self.current_token
        if (self.j.token_type() == "identifier"):
            pass

        self.get_next_token()
        array_flag = False
        if (self.j.token_type() == "symbol" and self.current_token == "["):
            array_flag = True
            self.get_next_token()
            self.CompileExpression()
            if (self.j.token_type() == "symbol" and self.current_token == "]"):
                pass
            self.writer.writePush(self.table.kindOf(var_name), self.table.indexOf(var_name))
            self.writer.writeArithmetic("ADD")
            self.get_next_token()

        self.checkSpecificToken("symbol", "=")
        self.get_next_token()
        self.CompileExpression()

        if (array_flag):
            self.writer.writePop("TEMP", 0)
            self.writer.writePop("POINTER", 1)
            self.writer.writePush("TEMP", 0)
            self.writer.writePop("THAT", 0)
        else:
            self.writer.writePop(self.table.kindOf(var_name), self.table.indexOf(var_name))
        self.checkSpecificToken("symbol", ";")

        self.get_next_token()


    def CompileIf(self):
        self.get_next_token()
        self.checkSpecificToken("symbol", "(")
        self.get_next_token()
        self.CompileExpression()
        current_condition_counter = self.condition_counter
        self.condition_counter += 1
        self.checkSpecificToken("symbol", ")")

        self.writer.writeIf("IF_TRUE" + str(current_condition_counter))
        self.writer.writeGoto("IF_FALSE" + str(current_condition_counter))

        self.writer.writeLabel("IF_TRUE" + str(current_condition_counter))


        self.get_next_token()
        self.checkSpecificToken("symbol", "{")
        self.get_next_token()
        self.CompileStatements()
        self.checkSpecificToken("symbol", "}")
        self.writer.writeGoto("IF_END" + str(current_condition_counter))

        self.writer.writeLabel("IF_FALSE" + str(current_condition_counter))
        self.get_next_token()
        if (self.j.token_type() == "keyword" and self.current_token == "else"):
            self.get_next_token()
            self.checkSpecificToken("symbol", "{")
            self.get_next_token()
            self.CompileStatements()
            self.checkSpecificToken("symbol", "}")
            self.get_next_token()
        self.writer.writeLabel("IF_END" + str(current_condition_counter))



    def CompileWhile(self):
        self.get_next_token()
        current_loop_counter = self.loop_counter
        self.loop_counter += 1
        self.writer.writeLabel("WHILE_EXP" + str(current_loop_counter))

        self.checkSpecificToken("symbol", "(")
        self.get_next_token()
        self.CompileExpression()
        self.checkSpecificToken("symbol", ")")
        self.writer.writeArithmetic("NOT")
        self.writer.writeIf("WHILE_END" + str(current_loop_counter))


        self.get_next_token()
        self.checkSpecificToken("symbol", "{")
        self.get_next_token()
        self.CompileStatements()
        self.checkSpecificToken("symbol", "}")

        self.writer.writeGoto("WHILE_EXP" + str(current_loop_counter))
        self.writer.writeLabel("WHILE_END" + str(current_loop_counter))
        self.get_next_token()


    def CompileDo(self):
        self.get_next_token()
        identifier_name = self.current_token
        if (self.j.token_type() == "identifier"):
            self.get_next_token()
            self.handleSubroutineCall(identifier_name)
            self.get_next_token()

        self.checkSpecificToken("symbol", ";")
        self.writer.writePop("TEMP", 0)
        self.get_next_token()


    def CompileReturn(self):
        self.get_next_token()
        if (not (self.j.token_type() == "symbol" and self.current_token == ";")):
            self.CompileExpression()
        else:
            self.writer.writePush("CONST", 0)
        self.checkSpecificToken("symbol", ";")

        self.writer.writeReturn()
        self.get_next_token()


    def CompileExpression(self):
        self.CompileTerm()

        while (self.j.token_type() == "symbol" and (self.current_token in opSet)):
            operator = self.current_token
            self.get_next_token()
            self.CompileTerm()
            self.write_operator(operator)


    def CompileTerm(self):
        ## if the token is an int, a string, a keyword or an unaryOp:
        if (self.j.token_type() == "integerConstant"):
            self.writer.writePush("CONST", self.current_token)
            self.get_next_token()

        elif (self.j.token_type() == "stringConstant"):
            self.writer.writePush("CONST", len(self.current_token))
            self.writer.writeCall("String.new", 1)
            for s in self.current_token:
                self.writer.writePush("CONST", ord(s))
                self.writer.writeCall("String.appendChar", 2)
            self.get_next_token()

        elif (self.j.token_type() == "keyword"):
            if (self.current_token == "null" or self.current_token == "false"):
                self.writer.writePush("CONST", 0)
            elif (self.current_token == "true"):
                self.writer.writePush("CONST", 0)
                self.writer.writeArithmetic("NOT")
            elif (self.current_token == "this"):
                self.writer.writePush("POINTER", 0)
            self.get_next_token()

        ## if the token is a an exression in paranethesis:
        elif (self.j.token_type() == "symbol" and self.current_token == "("):
            self.get_next_token()
            self.CompileExpression()
            self.checkSpecificToken("symbol", ")")
            self.get_next_token()

        elif (self.j.token_type() == "identifier"):
            identifier_name = self.current_token
            self.get_next_token()
            if (self.j.token_type() == "symbol" and self.current_token == "["):
                self.get_next_token()
                self.CompileExpression()
                self.checkSpecificToken("symbol", "]")
                self.put_var_name_in_that(identifier_name)
                self.writer.writePush("POINTER", 1)
                self.writer.writeArithmetic("ADD")
                self.writer.writePop("POINTER", 1)
                self.writer.writePush("THAT", 0)
                self.get_next_token()

            elif (self.j.token_type() == "symbol" and (self.current_token == "("
                   or self.current_token == "." )):
                self.handleSubroutineCall(identifier_name)
                self.get_next_token()

            else:
                self.put_var_in_stack(identifier_name)

        elif (self.j.token_type() == "symbol" and (self.current_token in unaryOpSet)):
            unary_operation = self.current_token
            self.get_next_token()
            self.CompileTerm()
            self.write_unary_operator(unary_operation)


    def handleSubroutineCall(self, identifier_name):
        if (self.current_token == "("):
            self.writer.writePush("POINTER", 0)
            nArgs = self.handleExpressionListCall() + 1
            self.writer.writeCall(self.class_name + "." + identifier_name, nArgs)

        elif (self.current_token == "."):
            self.get_next_token()
            subroutine_name = self.current_token
            if (self.j.token_type() == "identifier"):
                self.get_next_token()
                identifier_kind = self.table.kindOf(identifier_name)
                method_indicator = 0
                class_name = identifier_name
                if (identifier_kind != None):
                    self.writer.writePush(identifier_kind, self.table.indexOf(identifier_name))
                    method_indicator += 1
                    class_name = self.table.typeOf(identifier_name)
                nArgs = self.handleExpressionListCall() + method_indicator
                self.writer.writeCall(class_name + "." + subroutine_name, nArgs)



    def handleExpressionListCall(self):
        if (self.current_token == "("):
            self.get_next_token()
            if (self.j.token_type() == "symbol" and self.current_token == ")"):
                nArgs = self.CompileExpressionList(True)
            else:
                nArgs = self.CompileExpressionList(False)
                if (self.j.token_type() == "symbol" and self.current_token == ")"):
                    pass
            return nArgs


    def CompileExpressionList(self, zeroArguments):
        expressions_counter = 0
        if (not zeroArguments):
            self.CompileExpression()
            expressions_counter += 1
            while (self.j.token_type() == "symbol" and self.current_token == ","):
                self.get_next_token()
                self.CompileExpression()
                expressions_counter += 1
        return expressions_counter


    def put_var_name_in_that(self, var_name):
        self.put_var_in_stack(var_name)
        self.writer.writePop("POINTER", 1)


    def put_var_in_stack(self, var_name):
        var_name_kind = self.table.kindOf(var_name)
        if (var_name_kind != None):
            self.writer.writePush(var_name_kind,
                                  self.table.indexOf(var_name))


    def write_operator(self, operator):
        if (operator == "*"):
            self.writer.writeCall("Math.multiply", 2)

        elif (operator == "/"):
            self.writer.writeCall("Math.divide", 2)

        elif (operator == "+"):
            self.writer.writeArithmetic("ADD")

        elif (operator == "-"):
            self.writer.writeArithmetic("SUB")

        elif (operator == "="):
            self.writer.writeArithmetic("EQ")

        elif (operator == "&gt;"):
            self.writer.writeArithmetic("GT")

        elif (operator == "&lt;"):
            self.writer.writeArithmetic("LT")

        elif (operator == "&amp;"):
            self.writer.writeArithmetic("AND")

        elif (operator == "|"):
            self.writer.writeArithmetic("OR")


    def write_unary_operator(self, unary_operator):
        if (unary_operator == "-"):
            self.writer.writeArithmetic("NEG")

        elif (unary_operator == "~"):
            self.writer.writeArithmetic("NOT")


