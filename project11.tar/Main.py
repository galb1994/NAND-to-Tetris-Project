import sys
import os
from CompilationEngine import CompilationEngine


def main():
    path = sys.argv[1]
    if (not os.path.isdir(path)):
        file_name = path.strip("jack") + "xml"
        with open(file_name, 'w') as output:
            comp = CompilationEngine(path,output)
            comp.CompileClass()
    else:
        files = [file for file in os.listdir(path)]
        for file in files:
            if not file.endswith(".jack"):
                continue
            current_file_name = path + os.sep + file.strip("jack") + "vm"
            with open(current_file_name, 'w') as output:
                comp = CompilationEngine(path + os.sep + file, output)
                comp.CompileClass()


if __name__ == "__main__":
    main()


