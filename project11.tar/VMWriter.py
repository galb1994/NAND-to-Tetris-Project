class VMWriter:

    def __init__(self, file):
        self.output_file = file

    def convert_segment_name(self, segment):
        if (segment == "CONST"):
            return "constant"

        if (segment == "ARG"):
            return "argument"

        if (segment == "LOCAL" or segment == "VAR"):
            return "local"

        if (segment == "STATIC"):
            return "static"

        if (segment == "THIS" or segment == "FIELD"):
            return "this"

        if (segment == "THAT"):
            return "that"

        if (segment == "POINTER"):
            return "pointer"

        if (segment == "TEMP"):
            return "temp"


    def writePush(self, segment, index):
        self.output_file.write("push " + self.convert_segment_name(segment) + " " + str(index) + "\n")

    def writePop(self, segment, index):
        self.output_file.write("pop " + self.convert_segment_name(segment) + " " + str(index) + "\n")

    def writeArithmetic(self, command):
        self.output_file.write(command.lower() + "\n")

    def writeLabel(self, label):
        self.output_file.write("label " + label + "\n")

    def writeGoto(self, label):
        self.output_file.write("goto " + label + "\n")

    def writeIf(self, label):
        self.output_file.write("if-goto " + label + "\n")

    def writeCall(self, name, nArgs):
        self.output_file.write("call " + name + " " + str(nArgs) + "\n")

    def writeFunction(self, name, nLocals):
        self.output_file.write("function " + name + " " + str(nLocals) + "\n")

    def writeReturn(self):
        self.output_file.write("return" + "\n")

    def close(self):
        self.output_file.close()